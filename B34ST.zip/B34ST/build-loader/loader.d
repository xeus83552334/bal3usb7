build-loader/loader.o: loader/qemu_handoff/loader.c \
  include/fbr34ker/handoff.h include/fbr34ker/types.h
include/fbr34ker/handoff.h:
include/fbr34ker/types.h:
