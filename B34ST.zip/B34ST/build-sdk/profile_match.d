build-sdk/profile_match.o: sdk/src/profile_match.c \
  sdk/include/fbr34ker_sdk.h sdk/include/fbr34ker_bridge_protocol.h \
  sdk/include/fbr34ker_handoff.h sdk/include/fbr34ker_memory.h \
  sdk/include/fbr34ker_modules.h sdk/include/fbr34ker_services.h
sdk/include/fbr34ker_sdk.h:
sdk/include/fbr34ker_bridge_protocol.h:
sdk/include/fbr34ker_handoff.h:
sdk/include/fbr34ker_memory.h:
sdk/include/fbr34ker_modules.h:
sdk/include/fbr34ker_services.h:
